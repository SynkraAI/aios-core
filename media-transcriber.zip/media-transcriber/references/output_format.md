# Output Format Reference

## Standard Structured Transcription Template

Below is the expected markdown output format for structured transcriptions.

---

```markdown
# [Title derived from content]

**Source:** `filename.ext`
**Duration:** HH:MM:SS
**Language:** Portuguese (BR) / English / etc.
**Date transcribed:** YYYY-MM-DD

---

## Table of Contents

- [Section Name](#section-name) (00:00 - 05:30)
- [Section Name](#section-name) (05:30 - 12:15)
- ...

---

## Section Name
> **Type:** Educational Content | Sales Pitch | Testimonial | Q&A | Introduction | Conclusion | Transition
> **Timestamp:** 00:00 - 05:30

Transcription text for this section, cleaned up for readability.
Paragraphs separated by logical breaks in the speech.

---

## Section Name
> **Type:** Sales Pitch
> **Timestamp:** 05:30 - 08:45

Content of the sales pitch section...

---

## Key Takeaways

- Bullet point summary of main educational points
- Only from educational/content sections (exclude pitches)

## Mentions & References

- Books, tools, links, or resources mentioned in the content
```

---

## Section Type Classification

Use the following types to classify each section:

| Type | Description | Indicators |
|------|-------------|------------|
| **Educational Content** | Core teaching material, explanations, tutorials | Teaching tone, explanations, examples, step-by-step |
| **Sales Pitch** | Promotion of product, service, or course | Calls to action, pricing, urgency, links, discount codes |
| **Testimonial** | Success stories, social proof | "I did X and got Y", student results, case studies |
| **Q&A** | Questions and answers segment | Direct questions, audience interaction |
| **Introduction** | Opening of the content | Greetings, agenda overview, self-introduction |
| **Conclusion** | Closing of the content | Summary, final thoughts, sign-off |
| **Transition** | Brief bridge between sections | "Now let's talk about...", topic change |
| **Tangent** | Off-topic discussion or personal story | Anecdotes, side stories unrelated to main topic |
| **Sponsor/Ad** | Sponsored segment or advertisement | Sponsor mentions, ad reads, "this episode is brought to you by" |

## Guidelines

- Merge consecutive segments of the same type into a single section.
- Short transitions (< 30 seconds) may be merged into adjacent sections.
- When unsure about type, default to "Educational Content".
- Clean up filler words (uh, um, like) but preserve the speaker's voice and meaning.
- Fix obvious transcription errors in proper nouns when context makes them clear.
- Preserve technical terms exactly as spoken.
