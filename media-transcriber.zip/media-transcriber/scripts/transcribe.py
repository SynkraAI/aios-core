#!/usr/bin/env python3
"""
Media Transcriber - Extract and transcribe audio from media files using Whisper.

Dependencies:
    pip install openai-whisper
    brew install ffmpeg

Usage:
    python transcribe.py <media_file> [--model medium] [--language auto]
"""

import argparse
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path


AUDIO_EXTENSIONS = {".mp3", ".wav", ".m4a", ".flac", ".ogg", ".aac", ".wma", ".opus"}
VIDEO_EXTENSIONS = {".mp4", ".mkv", ".webm", ".avi", ".mov", ".wmv", ".flv", ".m4v"}


def check_dependencies():
    """Check if required dependencies are installed."""
    errors = []

    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
    except (FileNotFoundError, subprocess.CalledProcessError):
        errors.append("ffmpeg not found. Install with: brew install ffmpeg")

    try:
        import whisper  # noqa: F401
    except ImportError:
        errors.append("openai-whisper not found. Install with: pip install openai-whisper")

    if errors:
        for e in errors:
            print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)


def extract_audio(video_path: str, output_path: str) -> str:
    """Extract audio from video file using ffmpeg."""
    print(f"Extracting audio from: {video_path}")

    cmd = [
        "ffmpeg", "-i", video_path,
        "-vn",                    # No video
        "-acodec", "pcm_s16le",   # WAV format (best for Whisper)
        "-ar", "16000",           # 16kHz sample rate (Whisper optimal)
        "-ac", "1",               # Mono channel
        "-y",                     # Overwrite output
        output_path,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"ERROR: ffmpeg failed: {result.stderr}", file=sys.stderr)
        sys.exit(1)

    print(f"Audio extracted to: {output_path}")
    return output_path


def format_timestamp(seconds: float) -> str:
    """Convert seconds to HH:MM:SS or MM:SS format."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def transcribe(audio_path: str, model_name: str = "medium", language: str = None) -> dict:
    """Transcribe audio file using Whisper."""
    import whisper

    print(f"Loading Whisper model: {model_name}")
    model = whisper.load_model(model_name)

    print(f"Transcribing: {audio_path}")
    options = {}
    if language and language != "auto":
        options["language"] = language

    result = model.transcribe(audio_path, **options)
    return result


def save_raw_transcription(result: dict, output_path: str) -> dict:
    """Save raw transcription with timestamps to JSON."""
    detected_language = result.get("language", "unknown")

    output = {
        "language": detected_language,
        "full_text": result["text"],
        "segments": [],
    }

    for segment in result.get("segments", []):
        output["segments"].append({
            "start": segment["start"],
            "end": segment["end"],
            "start_formatted": format_timestamp(segment["start"]),
            "end_formatted": format_timestamp(segment["end"]),
            "text": segment["text"].strip(),
        })

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"Raw transcription saved to: {output_path}")
    return output


def main():
    parser = argparse.ArgumentParser(
        description="Transcribe audio/video files using OpenAI Whisper"
    )
    parser.add_argument("file", help="Path to audio or video file")
    parser.add_argument(
        "--model", default="medium",
        choices=["tiny", "base", "small", "medium", "large"],
        help="Whisper model size (default: medium). Larger = more accurate but slower.",
    )
    parser.add_argument(
        "--language", default=None,
        help="Language code (e.g., 'pt', 'en'). Default: auto-detect.",
    )
    parser.add_argument(
        "--output", default=None,
        help="Output JSON path. Default: <input_name>_transcription.json in same directory.",
    )

    args = parser.parse_args()

    input_path = Path(args.file).resolve()
    if not input_path.exists():
        print(f"ERROR: File not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    ext = input_path.suffix.lower()
    if ext not in AUDIO_EXTENSIONS and ext not in VIDEO_EXTENSIONS:
        print(f"ERROR: Unsupported format: {ext}", file=sys.stderr)
        print(f"Supported audio: {', '.join(sorted(AUDIO_EXTENSIONS))}")
        print(f"Supported video: {', '.join(sorted(VIDEO_EXTENSIONS))}")
        sys.exit(1)

    check_dependencies()

    audio_path = str(input_path)
    temp_audio = None

    if ext in VIDEO_EXTENSIONS:
        temp_audio = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        temp_audio.close()
        audio_path = extract_audio(str(input_path), temp_audio.name)

    try:
        result = transcribe(audio_path, model_name=args.model, language=args.language)

        if args.output:
            output_path = args.output
        else:
            output_path = str(input_path.parent / f"{input_path.stem}_transcription.json")

        save_raw_transcription(result, output_path)

        print(f"\nDetected language: {result.get('language', 'unknown')}")
        print(f"Total segments: {len(result.get('segments', []))}")
        print(f"Output: {output_path}")

    finally:
        if temp_audio and os.path.exists(temp_audio.name):
            os.unlink(temp_audio.name)


if __name__ == "__main__":
    main()
