---
name: media-transcriber
description: "This skill should be used when the user asks to transcribe, extract text from, or process audio/video files from their local machine. It handles any media format (mp4, mp3, wav, mkv, webm, m4a, etc.), extracts audio from video when needed, transcribes using OpenAI Whisper, and produces a structured markdown file with content sections classified by type (educational, sales pitch, testimonial, Q&A, etc.)."
---

# Media Transcriber

Transcribe local audio and video files into structured markdown documents using OpenAI Whisper. Automatically detect language (Portuguese/English), extract audio from video, and classify content sections by type.

## Prerequisites

Two dependencies are required. To check and install them:

```bash
# Check ffmpeg
ffmpeg -version

# Install ffmpeg if missing
brew install ffmpeg

# Check whisper
pip3 show openai-whisper

# Install whisper if missing
pip install openai-whisper
```

If the user's system lacks either dependency, inform them and provide the install commands above before proceeding.

## Workflow

### Step 1: Validate Input File

Confirm the file exists and identify its type by extension.

**Audio formats:** `.mp3`, `.wav`, `.m4a`, `.flac`, `.ogg`, `.aac`, `.wma`, `.opus`
**Video formats:** `.mp4`, `.mkv`, `.webm`, `.avi`, `.mov`, `.wmv`, `.flv`, `.m4v`

If the file format is not recognized, inform the user and list supported formats.

### Step 2: Run Transcription Script

Execute the bundled transcription script:

```bash
python3 scripts/transcribe.py "<file_path>" --model medium
```

**Model selection guidance:**
- `tiny` / `base` — Fast but lower accuracy. Use for quick previews or very long files (3h+).
- `small` — Good balance for clear audio.
- `medium` — Recommended default. Best accuracy-to-speed ratio.
- `large` — Maximum accuracy. Use for noisy audio or heavy accents. Significantly slower.

**Language override** (optional — auto-detect is default):
```bash
python3 scripts/transcribe.py "<file_path>" --model medium --language pt
```

The script outputs a `_transcription.json` file in the same directory as the source file, containing timestamped segments.

### Step 3: Read Raw Transcription

Read the generated `_transcription.json` file. The JSON structure contains:

```json
{
  "language": "pt",
  "full_text": "...",
  "segments": [
    {
      "start": 0.0,
      "end": 5.2,
      "start_formatted": "00:00",
      "end_formatted": "00:05",
      "text": "segment text"
    }
  ]
}
```

### Step 4: Analyze and Structure Content

This is the core intelligence step. Read `references/output_format.md` for the full output template and section type classification table.

**Content analysis process:**

1. **Read through all segments sequentially** to understand the overall content arc.
2. **Identify section boundaries** — look for topic changes, tone shifts, or explicit transitions.
3. **Classify each section** using the type taxonomy from the reference file:
   - Educational Content, Sales Pitch, Testimonial, Q&A, Introduction, Conclusion, Transition, Tangent, Sponsor/Ad
4. **Merge consecutive segments** of the same type into unified sections.
5. **Clean up the text** — remove filler words, fix punctuation, break into paragraphs at natural pauses.
6. **Preserve meaning** — do not alter technical terms, quotes, or the speaker's intent.

**Section boundary indicators:**
- Explicit verbal transitions: "agora vamos falar sobre...", "now let's move to..."
- Tone shift from teaching to selling (urgency, pricing, CTAs)
- Speaker change or audience interaction
- Topic change after a pause

### Step 5: Write Structured Markdown

Generate the final `.md` file in the **same directory** as the source file, named `<original_name>_transcription.md`.

Follow the template structure from `references/output_format.md`:
- Title derived from content
- Metadata block (source, duration, language, date)
- Table of contents with timestamps
- Classified sections with type badges and timestamps
- Key Takeaways (educational points only)
- Mentions & References (books, tools, links cited in the content)

### Step 6: Cleanup

After the structured markdown is written:
- Inform the user of the output file path.
- Optionally delete the intermediate `_transcription.json` if the user does not need it.
- Provide a brief summary: total duration, number of sections, detected language, and section type breakdown.

## Handling Edge Cases

- **Very long files (2h+):** Suggest using `--model small` or `--model base` to reduce processing time. Inform the user about the expected wait.
- **Poor audio quality:** Suggest `--model large` for better accuracy. Note that results may still contain errors.
- **Multiple speakers:** Note speaker changes in the markdown when detectable from context (e.g., Q&A format, interviewer vs guest).
- **Non-speech audio (music, silence):** Skip these segments. Note long pauses or music breaks as `[music]` or `[silence]` in the output.
- **Mixed languages:** Whisper handles code-switching. Note the primary and secondary languages in the metadata.
